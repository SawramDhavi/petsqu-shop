<?php
// jika belum login, tidak bisa mengakses halaman ini
session_start();
if (!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit;
}
require 'connect.php';
require 'item.php';
?>
<h2>Terima kasih telah membeli produk kami. Klik &nbsp;<a href="index.php">di sini</a> untuk lanjut berbelanja.</h2>