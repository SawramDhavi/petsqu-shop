<?php 
$a="CodePolitan"; 
echo "Error !!"; 
echo $b; ?>