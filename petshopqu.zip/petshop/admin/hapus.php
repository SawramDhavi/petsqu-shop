<?php
// gabisa akses halaman ini jika belum login
session_start();
if (!isset($_SESSION["Login"])) {
  header("Location: login-admin.php");
  exit;
}

// koneksi
require "../connect.php";
$sql = "delete from product where id='" . $_GET['id'] . "'";
$result = mysqli_query($con, $sql);
header("location:index.php");
