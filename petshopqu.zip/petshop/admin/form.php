<?php
// jika belum login gabisa akses halaman ini
session_start();
if (!isset($_SESSION["Login"])) {
  header("Location: login-admin.php");
  exit;
}

// koneksi
require "../connect.php";

// edit data produk
if (isset($_GET['id'])) {
  $id = $_GET['id'];
} else {
  $id = "";
}
$gambar = "";
$name = "";
$price = "";
$quantity = "";

$sql = $con->query("SELECT * FROM product where id='" . $id . "'");
while ($product = $sql->fetch_object()) {
  $gambar = $product->gambar;
  $name = $product->name;
  $price = $product->price;
  $quantity = $product->quantity;
}
?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <link rel="stylesheet" href="../style5.css">
  <title>PetshopQu</title>
</head>
<style>
  /* Back To Top Pure JS by igniel.com */
  #ignielToTop {
    display: none;
    z-index: 2;
    position: fixed;
    bottom: 20px;
    right: 20px;
    border-radius: 2px;
    cursor: pointer;
    transition: all .4s;
    width: 35px;
    height: 35px;
    background: #ed2849 url("data:image/svg+xml,%3Csvg viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M7.41,15.41L12,10.83L16.59,15.41L18,14L12,8L6,14L7.41,15.41Z' fill='%23fff'/%3E%3C/svg%3E") no-repeat center center
  }
</style>

<body>
  <!----------------------xxx--------------- Navbar ------------------xxxx---------------->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container container-fluid">
      <h2 style="font-weight: bold; color: #e8e9eb; font-family: Lobster;  text-shadow: 2px 2px rgba(5, 161, 161, 0.952);">Petsqu&nbsp;Shop</h2>
    </div>
  </nav>
  <!----------------------xxx--------------- Akhir navbar ------------------xxxx---------------->




  <!----------------------xxx--------------- Background ------------------xxxx---------------->
  <div class="background">
    <h1 style=" text-shadow: 2px 2px rgba(5, 161, 161, 0.952);" data-aos="zoom-in" data-aos-duration="900">Selamat berbelanja di Petsqu&nbsp;Shop</h1>
  </div>
  <!----------------------xxx--------------- akhir Background ------------------xxxx---------------->


  <!------------------- form ------------------>
  <div class="container mt-5 mb-5">
    <h2 class="text-center" style="font-family: Lobster;" data-aos="fade-down" data-aos-duration="600">Tambah atau ubah data Produk</h2>
    <div class="row justify-content-md-center">
      <form action="simpan.php" method="POST" class="col-sm-8">
        <div class="form-group">
          <label for="npm">id</label>
          <input type="text" name="id" value="<?php echo $id; ?>" class="form-control">
        </div>
        <div class="form-group">
          <label for="nama">Gambar</label>
          <input type="text" name="gambar" value="<?php echo $gambar; ?>" class="form-control">
        </div>
        <div class="form-group">
          <label for="kelas">Name</label>
          <input type="text" name="name" value="<?php echo $name; ?>" class="form-control">
        </div>
        <div class="form-group">
          <label for="kelas">Price</label>
          <input type="text" name="price" value="<?php echo $price; ?>" class="form-control">
        </div>
        <div class="form-group">
          <label for="kelas">Quantity</label>
          <input type="text" name="quantity" value="<?php echo $quantity; ?>" class="form-control">
        </div>
        <button type="submit" class="btn btn-danger" value="simpan">Simpan</button>
      </form>
    </div>
  </div>
  <!------------------- akhir form ------------------>


  <!----------- footer ----------->
  <footer class="bg-dark">
    <div class="container">
      <div class="row">
        <div class="col-sm-4" data-aos="fade-right" data-aos-duration="450">
          <h3 style="font-family: Lobster;">Follow us</h3>
          <p>&nbsp;&nbsp;<img src="../images/ig.png" width="47">&nbsp;@petsqushop</p>
          <p>&nbsp;&nbsp;<img src="../images/twitter.png" width="45">&nbsp;@petsqushop</p>
          <p> <img src="../images/fb.png" width="55">&nbsp;@Petsqu_shop</p>
        </div>
        <div class="col-sm-4" data-aos="fade-down" data-aos-duration="450">
          <h3 style="font-family: Lobster;">Contact</h3>
          <p>E-mail: petsqushop@gmail.com</p>
          <p>No. Hp : 095846382647</p>
        </div>
        <div class="col-sm-4" data-aos="fade-left" data-aos-duration="450">
          <h1 style="font-family: Lobster;">Petsqu&nbsp;Shop</h1>
          <h5>Location :</h5>
          <p>Jl. Perbatasan palestina israel No.20, RT.15/RW.5, Menteng, Kec. Menteng, Kota Jakarta Pusat,
            Daerah Khusus Ibukota Jakarta 10310</p>
        </div>
      </div>
      <hr class="bg-light">
      <div class="row logo text-center">
        <div class="col-sm-12">
          <h6>Copyright 2021 By Sawram</a> <img src="../images/footerr.png" style="width: 100px; padding: 15px 0px;"></h6>
        </div>
      </div>
    </div>
  </footer>

  <!-- Optional JavaScript; choose one of the two! -->
  <div id='ignielToTop' />
  <script>
    //<![CDATA[
    /* Back To Top Pure JS by igniel.com */
    var igniel_kecepatan = 1100; //kecepatan scroll
    var igniel_jarak = 300; //posisi munculnya tombol
    eval(function(p, a, c, k, e, d) {
      e = function(c) {
        return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36))
      };
      if (!''.replace(/^/, String)) {
        while (c--) {
          d[e(c)] = k[c] || e(c)
        }
        k = [function(e) {
          return d[e]
        }];
        e = function() {
          return '\\w+'
        };
        c = 1
      };
      while (c--) {
        if (k[c]) {
          p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c])
        }
      }
      return p
    }('f 7=["\\h\\a\\g\\h\\F","\\C\\h\\w\\c\\a\\a\\l\\c\\v","\\e\\c\\h\\K\\p\\9\\d\\b\\m\\a\\9\\p\\9\\d\\b","\\G\\c\\e\\q","\\J\\e\\e\\m\\I\\9\\d\\b\\H\\g\\C\\b\\9\\d\\9\\w","\\g\\u\\d\\g\\9\\a\\l\\c\\l\\c\\v","\\u\\9\\b\\m\\a\\9\\p\\9\\d\\b\\M\\q\\U\\e"];8[7[6]](7[5])[7[4]](7[0],j x(){f i=8[7[2]][7[1]]||8[7[3]][7[1]];o(k<=0){s};f r=0-i;f t=r/k*X;L(j(){8[7[3]][7[1]]=8[7[2]][7[1]]=i+t;o(i==0){s};x(8[7[3]],0,k)},P)},Q);B.Y(\'O\',j(){o(B.N>=n||8.R.z>=n||8.W.z>=n){8.y(\'A\').E.D=\'V\'}T{8.y(\'A\').E.D=\'S\'}});', 61, 61, '|||||||_0x3e17|document|x65|x6C|x74|x6F|x6E|x64|var|x69|x63|_0x2ceax2|function|igniel_kecepatan|x54|x45|igniel_jarak|if|x6D|x79|_0x2ceax3|return|_0x2ceax4|x67|x70|x72|ignielScroll|getElementById|scrollTop|ignielToTop|window|x73|display|style|x6B|x62|x4C|x76|x61|x75|setTimeout|x42|pageYOffset|scroll|10|false|documentElement|none|else|x49|block|body|50|addEventListener'.split('|'), 0, {}));
    //]]>
  </script>

  <!------------------------- jquery on scroll ------------------------------>
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
    AOS.init();
  </script>

  <!-- Optional JavaScript; choose one of the two! -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
  <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
</body>

</html>