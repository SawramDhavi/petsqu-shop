<?php
// harus login jika ingin mengakses halaman admin
session_start();

// koneksi
require "../connect.php";
if (isset($_POST["login"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $result = mysqli_query($con, "SELECT * FROM dataadmin WHERE username = '$username'");

    // cek username
    if (mysqli_num_rows($result) === 1) {

        // cek password
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row["password"])) {

            // set session
            $_SESSION["Login"] = true;
            header("Location: index.php");
            exit;
        }
    }

    $error = true;
}
?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;1,300;1,400&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet">
    <title>Halaman Login</title>
    <style>
        /* animasi  */
        .animate__animated.animate__flipInX {
            --animate-duration: 1.5s;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background-image: url(../images/kucing3.jpg);
            background-size: cover;
            animation-name: animasi_login;
            animation-duration: 15s;
            animation-iteration-count: infinite;
            animation-direction: alternate;
            animation-timing-function: ease-in;
        }

        /* animasi */
        @keyframes animasi_login {
            0% {
                background-image: url(../images/kucing3.jpg);
            }

            40% {
                background-image: url(../images/bck2.jpeg);
            }

            100% {
                background-image: url(../images/kucing1.jpg);
            }
        }
    </style>
</head>

<body style="min-height: 500px;">

    <!------------------------------------- form ---------------------------------->
    <form action="" method="POST" style="width: 300px; margin: 120px auto; padding: 30px 20px 1px 20px; background-color: black; opacity: 1; border-radius: 10px;  box-shadow: 0px 0px 10px white;" class="animate__animated animate__flipInX">
        <img src="../images/akun.png" class="rounded-circle" width="90" style="margin-left: 32%; margin-bottom: 14px;">
        <br>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1">@</span>
            <input type="text" name="username" id="username" class="form-control" placeholder="Username" aria-label="username" aria-describedby="basic-addon1" autocomplete="off" required>
        </div>
        <div class="input-group mb-3">
            <span class="input-group-text" id="basic-addon1"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-lock" viewBox="0 0 16 16">
                    <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2zM5 8h6a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z" />
                </svg></span>
            <input type="password" name="password" id="password" class="form-control" placeholder="Password" aria-label="password" aria-describedby="basic-addon1" required>
        </div>
        <?php if (isset($error)) : ?>
            <p class="animate__animated animate__bounce" style="color: white;">username / password salah</p>
        <?php endif ?>
        <button type="submit" name="login" class="btn btn-danger" style="width: 260px;">Login</button>
        <br>
        <a href="regisadmin.php" class="text-center">Registrasi?</a>
        <br>
        <br>
        <div style="font-size: 10px; text-align: center; color: white;">
        </div>
    </form>
    <!------------------------------------- akhir form ---------------------------------->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
</body>

</html>