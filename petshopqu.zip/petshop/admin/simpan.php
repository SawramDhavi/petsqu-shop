<?php
// gabisa akses halaman ini kalo belum login
session_start();
if (!isset($_SESSION["Login"])) {
  header("Location: login-admin.php");
  exit;
}

// koneksi
require "../connect.php";

// jika data sudah ada diupdate, tetapi jika data belum ada akan ditambah
$sql = $con->query("SELECT * FROM product WHERE id='" . $_POST['id'] . "'");
$jml = $sql->num_rows;
if ($jml > 0) {
  $con->query("update product set gambar='" . $_POST['gambar'] . "', name='" . $_POST['name'] . "', price='" . $_POST['price'] . "', quantity='" . $_POST['quantity'] . "' WHERE id='" . $_POST['id'] . "'");
} else {
  $con->query("insert into product (id, gambar, name, price, quantity) values ('" . $_POST['id'] . "','" . $_POST['gambar'] . "','" . $_POST['name'] . "', '" . $_POST['price'] . "', '" . $_POST['quantity'] . "')");
}

header("location: index.php");
