<?php
// membuat koneksi database
$servername = 'localhost';
$username = 'root';
$password = '';
$db = 'petsqushop';
$con = mysqli_connect($servername, $username, $password, $db);
// cek koneksi
if (!$con) {
	die("connection failed." . mysqli_connect_error()); //close connection
}

function registrasi($data)
{
	global $con;

	$username = strtolower(stripslashes($data["username"]));
	$password = mysqli_real_escape_string($con, $data["password"]);
	$password2 = mysqli_real_escape_string($con, $data["password2"]);
	$age = strtolower(stripslashes($data["age"]));
	$address = strtolower(stripslashes($data["address"]));

	// cek konfirmasi password
	if ($password !== $password2) {
		echo "<script>
				alert('konfirmasi password tidak sesuai');
			   </script>";
		return false;
	}
	// enkripsi password
	$password = password_hash($password, PASSWORD_DEFAULT);

	// tambahkan user baru ke database
	mysqli_query($con, "INSERT INTO data VALUES ('','$username', '$password', '$age', '$address')");

	return mysqli_affected_rows($con);
}



// admin
function registeradmin($dataadmin)
{
	global $con;

	$username = strtolower(stripslashes($dataadmin["username"]));
	$password = mysqli_real_escape_string($con, $dataadmin["password"]);
	$password2 = mysqli_real_escape_string($con, $dataadmin["password2"]);
	$age = strtolower(stripslashes($dataadmin["age"]));
	$address = strtolower(stripslashes($dataadmin["address"]));

	// cek konfirmasi password
	if ($password !== $password2) {
		echo "<script>
				alert('konfirmasi password tidak sesuai');
			   </script>";
		return false;
	}
	// enkripsi password
	$password = password_hash($password, PASSWORD_DEFAULT);

	// tambahkan user baru ke database
	mysqli_query($con, "INSERT INTO dataadmin VALUES ('','$username', '$password', '$age', '$address')");

	return mysqli_affected_rows($con);
}
