<?php
// ketika logout maka akan kembali ke tampilan login
session_start();
$_SESSION = [];
session_unset();
session_destroy();

header("Location: login.php");
exit;
